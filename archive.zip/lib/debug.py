#!/usr/bin/python
# -*- coding: utf-8 -*-
# debug.py
# described by Kazushi Yamashina

class Debug(object):
	"""docstring for Debug"""
	def __init__(self):
		pass
	def o(self, variable):
		print variable
	def qo(self, variable):
		print variable
		quit()
